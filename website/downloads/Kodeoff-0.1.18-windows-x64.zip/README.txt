Kodeoff 0.1.18 (build 1)

Kodeoff for Windows
===================

Kodeoff 是拖拽呼出轮盘的文件动作工具：按住文件拖动、光标停顿即弹出动作轮盘，
滑向扇区松手执行——打开、定位、复制路径、新建同格式、终端打开等，不必先找
目标应用。本包为 Windows 绿色版，免安装。

运行要求
--------
- Windows 10 及以上，x64
- 请完整解压到任意目录后运行：kodeoff.exe 需要同目录的 WebView2Loader.dll，
  只把 exe 拖出压缩包会缺 DLL 无法启动
- 设置页优先使用 Microsoft Edge WebView2 Runtime；系统缺少时自动退回原生
  设置页，轮盘与本地文件动作不依赖 WebView2，程序也不会自动下载运行时
- 首版无数字签名，SmartScreen 可能提示"仍要运行"

使用要点
--------
- 拖动文件/文件夹时把光标停顿一下（默认 300ms）弹出轮盘，
  按住滑向扇区、松手即执行；中心死区或拖出边界=取消
- 手动启动显示设置；关闭设置后常驻托盘。再次双击会唤回设置。
- 托盘左键=设置，右键菜单=启用/停用、设置、关于、退出；自启使用 --background。
- 轮盘动作（7 个）：VSCode 打开 / 复制路径 / 打开方式 / 新建同格式 /
  在资源管理器中显示 / 终端打开 / 设置。打开方式仅支持单个普通文件。
- 已有配置保留原动作勾选；新增动作可在设置中开启。
- 设置存于 %APPDATA%\Kodeoff\settings.ini
- 启动诊断：%APPDATA%\Kodeoff\kodeoff.log。
- 在测试桌面可运行 kodeoff.exe --self-test（会短暂使用并恢复剪贴板）。
- 卸载=删除解压目录 + 删除上述 %APPDATA%\Kodeoff 目录

官网与反馈
----------
- 官网：https://www.kodeoff.com
- 问题反馈：https://github.com/kk0x03/kodeoff-release/issues
  （反馈请附平台、版本、复现步骤与错误提示；请勿附密码、凭据或私人文件）

如实边界
--------
本地交叉构建不等于 Windows 真机验证。原生 CI 已加入 --self-test，
本轮交付尚待 Windows 10/11 真机确认。
尚未与 macOS 等齐：静止长按文件的选择/执行链路、快捷编辑/重命名、
压缩/解压、账号/发手机/分享链接、截图、剪贴板同步和布局拖排。
完整复审记录：docs/2026-10-16-Windows复审.md。
